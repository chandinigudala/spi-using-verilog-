// Code your testbench here
// or browse Examples
module tb;
  reg clk,cs;
  reg [7:0]master_in,slave_in;
  wire [7:0]master_data,slave_data;
  initial clk=0;
  always #5 clk=~clk;
  initial begin
    cs=1;
    master_in=8'b10101010;
    slave_in=8'b11111110;#10
    cs=0;
    master_in=8'b10101010;
    slave_in=8'b11111110;
  end
  
  initial begin
    repeat (30) @(posedge clk) 
    $monitor("clk:%b,cs:%b,master_in:%b,slave_in:%b,master_data:%b,slave_data:%b",clk,cs,master_in,slave_in,master_data,slave_data);
     $stop();
  end
  
  
  top d1(.clk(clk),.cs(cs),.master_in(master_in),.slave_in(slave_in),.master_data(master_data),.slave_data(slave_data));
endmodule

    
