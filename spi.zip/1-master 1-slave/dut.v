// Code your design here
module master(
  input clk,cs,
  input [7:0]master_in,
  input miso,
  output reg mosi,
  output reg[7:0]master_data
);
  reg [7:0]mem_master;
  always @(posedge clk) begin
    if (cs==1) begin
      mem_master<=master_in;
      master_data<=master_in;
    
    end
    else begin
      mosi<=mem_master[0];
      mem_master<={miso,mem_master[7:1]};
      master_data<=mem_master;
    end
  end
endmodule
module slave(
  input clk,cs,
  input [7:0]slave_in,
  input mosi,
  output reg miso,
  output reg [7:0]slave_data
);
  reg [7:0]mem_slave;
  always @(posedge clk) begin
    if (cs==1) begin
      mem_slave<=slave_in;
      slave_data<=slave_in;
    end
    else begin
      miso<=mem_slave[0];
      mem_slave<={mosi,mem_slave[7:1]};
      slave_data<=mem_slave;
    end
  end
endmodule
module top(
  input clk,cs,
  input [7:0]master_in,slave_in,
  output  [7:0]master_data,slave_data
); 
  wire miso,mosi;
  master a1(.clk(clk),.cs(cs),.master_in(master_in),.miso(miso),.mosi(mosi),.master_data(master_data));
  slave a2(.clk(clk),.cs(cs),.slave_in(slave_in),.miso(miso),.mosi(mosi),.slave_data(slave_data));
endmodule

  

